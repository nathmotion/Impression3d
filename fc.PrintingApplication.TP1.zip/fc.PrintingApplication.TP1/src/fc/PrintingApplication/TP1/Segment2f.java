package fc.PrintingApplication.TP1;

import com.owens.oobjloader.builder.VertexGeometric;

public class Segment2f {
	VertexGeometric p1;
	VertexGeometric p2;
	
	public Segment2f(){
		
	}

	public Segment2f(VertexGeometric p1, VertexGeometric p2) {
		
		this.p1 = p1;
		this.p2 = p2;
	}
	
	
}
