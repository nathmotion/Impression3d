package fc.PrintingApplication.TP1;

import java.util.ArrayList;

public class Triangle {
	ArrayList<Vec3f> v=new ArrayList<Vec3f>() ;
	
	
	
	

	
	
	
}




